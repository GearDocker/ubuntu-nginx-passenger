name "wrapper"

description "The wrapper cookbook self contained config Base.1,b58dff6f8e5dd918057c6e1fdc3306d0.b1f0d18bad97e892c8b29bbffcada210"

run_list "recipe[custom::default]"

