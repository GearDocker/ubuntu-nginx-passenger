name "wrapper"

description "The wrapper cookbook self contained config QB0PKDCJMH9X40II"

run_list "role[nginx_passenger]", "recipe[apt::default]", "recipe[build-essential::default]", "recipe[ruby_build::default]", "recipe[passenger::install_ruby]", "recipe[nginx::source]"

