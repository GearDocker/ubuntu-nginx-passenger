#Created by jiffy automatically.

group_name "Ubuntu/Nginx/Passenger"
group_ref_hash "740ca7760ecee03bbd5980a8ad084d27"
